## Number guesser

Realizza una pagina dove gli utenti possono giocare a indovinare il numero segreto estratto. Mostra se ha vinto o se ha perso.

Un esempio di come dovrebbe funzionare: https://content.codecademy.com/PRO/independent-practice-projects/number-guesser/example/index.html

1. Crea la funzione che genera un numero randomico ed eseguila
2. L'utente inserirà il numero che pensa sia stato estratto, al click verifica se l'utente ha indovinato o meno
3. Visualizza un messaggio all'utente che gli indichi se ha vinto o se ha perso

4. Aggiungi un button che permette di resettare il gioco
5. Aggiungi un contatore delle vittore da parte dell'utente e mostrale
